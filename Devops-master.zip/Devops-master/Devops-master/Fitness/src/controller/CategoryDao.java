package controller;

public interface CategoryDao {

}
