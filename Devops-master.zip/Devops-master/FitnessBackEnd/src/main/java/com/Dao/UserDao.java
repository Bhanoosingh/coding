package com.Dao;

import com.model.*;
public interface UserDao 
{
	public void insertUser(UserDao user);
}
