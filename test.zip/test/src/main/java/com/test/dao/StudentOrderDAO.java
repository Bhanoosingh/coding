package com.test.dao;

import com.test.model.StudentOrder;


public interface StudentOrderDAO 
{
	void addStudentOrder(StudentOrder studentOrder);
}
